<?php

namespace Controllers;

class LoginController
{
    public static function login()
    {
        echo "Desde Login";
    }
}
